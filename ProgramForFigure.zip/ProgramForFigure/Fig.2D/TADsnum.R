rm(list=ls())
setwd("/media/disk1/lilin/1-lilin_xiugai/real result")

Ave_len <- function(dirpath){
  dir <- list.files(dirpath,full.names = T)
  alllen <- c()
  for (i in 1:6) {
    onelist <- read.table(dir[i])
    onelist <- as.matrix(onelist)
    listlen <- length(onelist)
    alllen <- c(alllen,listlen)
  }
  value <- round(sum(alllen)/6, digits = 1)
  return(value)
}

dirpath = "./all results/K562-chr1-100k"
dir <- list.files(dirpath,full.names = T)
TADBDlen <- Ave_len(dir[3])
Spectrallen <- Ave_len(dir[6])
HiCDBlen <- Ave_len(dir[5])
ICFinder <- Ave_len(dir[4])
EASTlen <- Ave_len(dir[1])
Topdomlen <- Ave_len(dir[7])
HiCseglen <- Ave_len(dir[2])
# ################
hei <- c(TADBDlen,Spectrallen,HiCDBlen,ICFinder,EASTlen,Topdomlen,HiCseglen)
col<-c("red","purple","green","blue","magenta","brown","orange") 
names<-c("TADBD","SpectralTAD","HiCDB","IC-Finder","EAST","TopDom","HiCseg")
tiff("./pic results_50000/K562-chr1-100k/Peaksnum.TIFF", width = 2.73, height = 2.75, units = "cm", pointsize=1, res=350)
par(bty = "l", xaxs = "r", yaxs = "r",  mar=c(27, 10.3, 4, 0), mgp=c(6,2,1), lwd=0.2, cex.axis=5, cex.lab=5)
bar <- barplot(hei, col = col, ylab="Number of TADs",axis.lty=1, names.arg=names,las = 3,lwd=0.2)
text(x=as.vector(bar),y=hei+15,labels=sprintf("%0.1f",hei),cex =4, xpd=T)
dev.off()
