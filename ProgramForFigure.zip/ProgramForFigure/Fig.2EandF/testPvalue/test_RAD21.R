rm(list=ls())
setwd("/media/disk1/lilin/1-lilin_xiugai/real Test")
source("./ctcf1.R")
chr<-"chr1"
ctcf<-read.table("/media/disk1/lilin/CTCF/data/RAD21/GSM803447_hg19_K562(1).broadPeak")
# chr<-"chr18"
# ctcf<-read.table("/media/disk1/lilin/CTCF/data/RAD21/GSM935624_hg19_IMR90.narrowPeak")
resolution <- 100000

Test <- function(dirpath,Wpath){
  dir <- list.files(dirpath,full.names = T)
  for (i in 1:6) {
    DOM <- read.table(dir[i],header = T)
    DOM <- c(as.matrix(DOM))+1
    DOM <- sort(DOM)
    if(DOM[2]<1000){
      DOM <- DOM*resolution
    }
    DOM <- c(DOM/resolution)
    alldom <- 0:DOM[length(DOM)]
    alldom_exc <- alldom
    for (i in 1:length(DOM)) {
      alldom_exc <-alldom_exc[alldom_exc!=DOM[i]]
    }
    Sampledom <- sort(sample(alldom_exc,length(DOM)))
    DOM <- as.matrix(DOM*resolution)
    Sampledom <- as.matrix(Sampledom*resolution)
    
    Dom_num=c(CTCF(ctcf,out=DOM,chr,50000))
    Sam_num=c(CTCF(ctcf,out=Sampledom,chr,50000))
    pvalue <- ks.test(Sam_num, Dom_num,  alternative="greater")$p.value
    print(pvalue)
    write.table(pvalue,Wpath,append = T, row.names = F,col.names = F)
  }
}

dirpath <- "./all results/IMR90-chr18-100k/EAST"
Wpath <- "./all results/IMR90-chr18-100k/pRAD21_50000/EASTp.txt"
Test(dirpath,Wpath)
dirpath <- "./all results/IMR90-chr18-100k/HiCseg"
Wpath <- "./all results/IMR90-chr18-100k/pRAD21_50000/hicsegp.txt"
Test(dirpath,Wpath)
print("start TADBD")
dirpath <- "./all results/K562-chr1-100k/HMDTB"
Wpath <- "./all results/K562-chr1-100k/pRAD21_50000/TADBDp.txt"
Test(dirpath,Wpath)
print("end")
dirpath <- "./all results/IMR90-chr18-100k/IC_Finder"
Wpath <- "./all results/IMR90-chr18-100k/pRAD21_50000/ICFinderp.txt"
Test(dirpath,Wpath)
dirpath <- "./all results/IMR90-chr18-100k/RHiCDB"
Wpath <- "./all results/IMR90-chr18-100k/pRAD21_50000/HiCDBp.txt"
Test(dirpath,Wpath)
print("start spectral")
dirpath <- "./all results/IMR90-chr18-100k/SpectralTAD"
Wpath <- "./all results/IMR90-chr18-100k/pRAD21_50000/Spectralp.txt"
Test(dirpath,Wpath)
print("End")
dirpath <- "./all results/IMR90-chr18-100k/topdom"
Wpath <- "./all results/IMR90-chr18-100k/pRAD21_50000/topdomp.txt"
Test(dirpath,Wpath)

