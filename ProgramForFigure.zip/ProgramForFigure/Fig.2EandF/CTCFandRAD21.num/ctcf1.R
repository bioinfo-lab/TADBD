CTCF<-function(ctcf,out,chr,rev)
{
 
  chr <- chr
  data<-out
  GSM<-ctcf
  data.len<-dim(data)[1]
  GSM.len<-dim(GSM)[1]
  chromStart<-c()
  chromEnd<-c()
  signalValue<-c()
  ch<-0
  for(i in 1:GSM.len) {
    if(GSM[i,1]==chr){
      ch<-ch+1
      chromStart[ch]<-GSM[i,2]
      chromEnd[ch]<-GSM[i,3]
      signalValue[ch]<-GSM[i,7]
    }
  }
  GSM.chr.len<-ch
  GSM.chr<-list(chromStart=chromStart,chromEnd=chromEnd)
  number<-matrix(0,nrow=data.len,ncol=1)
  data.use<-data[,1]
  for (j in 1:data.len)
  {
    for(k in 1:GSM.chr.len)
    {
      if(data.use[j]-rev <= GSM.chr$chromStart[k] && data.use[j]+rev>=GSM.chr$chromEnd[k])
      {
        number[j]=number[j]+1
      }
      else if(data.use[j]-rev >GSM.chr$chromStart[k] && data.use[j]-rev<GSM.chr$chromEnd[k])
      {
        number[j]=number[j]+(GSM.chr$chromEnd[k]-data.use[j]+rev)/(GSM.chr$chromEnd[k]-GSM.chr$chromStart[k])
      }
      else if(data.use[j]+rev >GSM.chr$chromStart[k] && data.use[j]+rev<GSM.chr$chromEnd[k])
      {
        number[j]=number[j]+(data.use[j]+rev-GSM.chr$chromStart[k])/(GSM.chr$chromEnd[k]-GSM.chr$chromStart[k])
      }
    }
    
  }
  return(number)
}
