rm(list=ls())
setwd("/media/disk1/lilin/1-lilin_xiugai/real result")
source("./pic code/CTCFRADnums/ctcf1.R")

Alltads <- function(dirpath){
  dir <- list.files(dirpath,full.names = T)
  alllist <- c()
  for (i in 1:6) {
    onelist <- read.table(dir[i],header = T)
    onelist <- c(as.matrix(onelist))
    if(onelist[3]<1000){
      onelist <- onelist*resolution
    }
    alllist <- c(alllist,onelist)
  }
  return(alllist)
}

chr<-"chr1"
resolution <- 100000
# ctcf<-read.table("/media/disk1/lilin/CTCF/data/CTCF/GSM935404_hg19_IMR90.narrowPeak")
# dirpath <- "./all results/IMR90-chr18-100k"
ctcf<-read.table("/media/disk1/lilin/CTCF/data/CTCF/GSM733719_hg19_K562.broadPeak")
dirpath <- "./all results/K562-chr1-100k"
dir <- list.files(dirpath,full.names = T)

alltads <- as.matrix(Alltads(dir[3]))
TADBD.num=CTCF(ctcf,out=alltads,chr,50000)
alltads <- as.matrix(Alltads(dir[6]))
Spectral.num=CTCF(ctcf,out=alltads,chr,50000)
alltads <- as.matrix(Alltads(dir[5]))
HiCDB.num=CTCF(ctcf,out=alltads,chr,50000)
alltads <- as.matrix(Alltads(dir[4]))
ICFinder.num=CTCF(ctcf,out=alltads,chr,50000)
alltads <- as.matrix(Alltads(dir[1]))
EAST.num=CTCF(ctcf,out=alltads,chr,50000)
alltads <- as.matrix(Alltads(dir[7]))
Topdom.num=CTCF(ctcf,out=alltads,chr,50000)
alltads <- as.matrix(Alltads(dir[2]))
HiCseg.num=CTCF(ctcf,out=alltads,chr,50000)

final=list(TADBD.num,Spectral.num,HiCDB.num,ICFinder.num,EAST.num,Topdom.num,HiCseg.num)
col<-c("red","purple","green","blue","magenta","brown","orange") 
names<-c("TADBD","SpectralTAD","HiCDB","IC-Finder","EAST","TopDom","HiCseg")
tiff("./pic results_50000/K562-chr1-100k/CTCF_50000.TIFF", width = 2.73, height = 2.75, units = "cm", pointsize=1, res=350)
par(bty = "l", xaxs = "r", yaxs = "r", mar=c(27, 10.3, 0, 0), mgp=c(6,1,0), lwd=0.2, cex.axis=5, cex.lab=5)
boxplot(final, range = 1, outline=FALSE,col=col,ylab="Number of peaks",axes = FALSE)#pars = list(boxwex = 0.5, staplewex = 0.5, outwex = 0.5)
axis(side = 1, lwd = 0.2, las = 2, at = 1:length(names), labels = names)
axis(side = 2, lwd = 0.2)
dev.off()
