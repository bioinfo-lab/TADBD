rm(list=ls())
path_folder <- "/media/disk1/lilin/1-lilin_xiugai/sim heatmap/heatmap"
setwd(path_folder)
source("./heatmap.R")
library(gplots)

hicdata<-read.table("/media/disk1/lilin/simulated heatmap/MCC/simu/4 noise/data/data2.txt", head=FALSE)
hicmat<-as.matrix(hicdata)
boundry1 <- read.table("/media/disk1/lilin/1-lilin_xiugai/sim heatmap/boundry/spectralTAD/spectral4.dom", head=TRUE)
x_peaks1 <- boundry1$V1
heatmap (hicmat,x_peaks1, "./4 noise/7SpectralTAD.TIFF")

# hicmat<-as.matrix(hicdata)
boundry2 <- read.table("/media/disk1/lilin/simulated heatmap/boundry/HiCseg/HiCseg4.dom", head=TRUE)
x_peaks2 <- boundry2$V1
heatmap (hicmat,x_peaks2, "./4 noise/6HiCseg.TIFF")

boundry3 <- read.table("/media/disk1/lilin/simulated heatmap/boundry/IC_Finder/IC_Finder4.dom", head=TRUE)
x_peaks3 <- boundry3$x
heatmap (hicmat,x_peaks3, "./4 noise/4IC_Finder.TIFF")

boundry4 <- read.table("/media/disk1/lilin/simulated heatmap/boundry/TADBD/TADBD4.dom", head=TRUE)
x_peaks4 <- boundry4$x
heatmap (hicmat,x_peaks4, "./4 noise/2TADBD.TIFF")

boundry5 <- read.table("/media/disk1/lilin/simulated heatmap/boundry/TADs/TADs4.dom", head=TRUE)
x_peaks5 <- boundry5$x
heatmap (hicmat,x_peaks5, "./4 noise/1TADs.TIFF")

boundry6 <- read.table("/media/disk1/lilin/simulated heatmap/boundry/TopDom/TopDom4.dom", head=TRUE)
x_peaks6 <- boundry6$V1
heatmap (hicmat,x_peaks6, "./4 noise/5TopDom.TIFF")

boundry7 <- read.table("/media/disk1/lilin/simulated heatmap/boundry/HiCDB/HiCDB4.dom", head=TRUE)
x_peaks7 <- boundry7$V1
heatmap (hicmat,x_peaks7, "./4 noise/3HiCDB.TIFF")

boundry8 <- read.table("/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/4 noise/EAST/EAST_4.dom", head=TRUE)
boundry8 <-as.matrix(boundry8)
x_peaks8 <- boundry8
heatmap (hicmat,x_peaks8, "./4 noise/8EAST.TIFF")