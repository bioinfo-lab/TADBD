# rm(list=ls())
# path_folder <- "/media/disk1/lilin/simulated heatmap/heatmap"
# setwd(path_folder)
# library(gplots)

# hicdata<-read.table("/media/disk1/lilin/simulated heatmap/MCC/simu/4 noise/data/data2.txt", head=FALSE)
# hicmat<-as.matrix(hicdata)
# boundry <- read.table("/media/disk1/lilin/simulated heatmap/boundry/HiCDB/HiCDB4.dom", head=TRUE)
# x_peaks <- boundry$V1
############# Lines X Y ##############
Coordinate <- function(listC, map_up, map_down)
{
  ax <- c()
  ay <- c()
  bx <- c()
  by <- c()
  j <- 1
  for(i in 1:length(listC))
  {
    if (listC[i] >= map_up)
    {
      ax[j] <- listC[i]
      ay[j] <- listC[i]
      if (i == length(listC) | listC[i+1]>=map_down)
      {
        break
      } 
      else
      {
        bx[j] <- listC[i+1]
        by[j] <- listC[i]
      }
      j <- j + 1
    }
  }
  axx <- c()
  ayy <- c()
  for(i in 1:length(ax))
  {
    axx <- c(axx,ax[i],ax[i])
    ayy <- c(ayy,ay[i],ay[i])
  }
  bxx <- c()
  byy <- c()
  for(i in 1:length(bx))
  {
    bxx <- c(bxx,bx[i],bx[i])
    byy <- c(byy,by[i],by[i])
  }
  Laxx <- c(map_up,axx,map_down) - map_up + 1
  Layy <- (map_down) - c(map_up,axx,map_down) + map_up- map_up + 1
  Lbxx <- c(axx[1],axx[1],bxx,map_down,map_down)- map_up + 1
  Lbyy <- (map_down) - c(map_up,map_up,byy,axx[length(axx)],axx[length(axx)]) + map_up- map_up + 1
  LXY <- data.frame(Laxx, Layy, Lbxx, Lbyy)
  return(LXY)
}
#######################
heatmap <- function(hicmat,x_peaks, path)
{
  map_up <- 200
  map_down <- 400
  # x_peaks_resolution <- outfile$end
  # x_peaks <- x_peaks_resolution/resolution + 1
  # for(i in 1:length(x_peaks))
  # {
  #   hicmat[x_peaks[i],x_peaks[i]] <- 0
  # }
  hicmat <- log10(hicmat+1)
  hicmat <- hicmat[c(map_up:map_down),c(map_up:map_down)]
  x_peaks <<- x_peaks
  # "./4 noise/HiCDB.TIFF"
  tiff(path, width = 18, height = 18, units = "cm", res=350)
  LXY <- Coordinate(x_peaks, map_up, map_down)
  Laxx <<- LXY$Laxx
  Layy <<- LXY$Layy
  Lbxx <<- LXY$Lbxx
  Lbyy <<- LXY$Lbyy
  heatmap.2(hicmat, Rowv=FALSE,col=colorpanel(128,"lightyellow","red"),symm=TRUE,dendrogram="none",
            trace = "none",labRow = FALSE,labCol = FALSE,density.info="none",key=FALSE,
            lmat=rbind(c(1,4),c(3,2)),lhei=c(7,1),lwid=c(7,1),
            add.expr=for(j in 1:length(Laxx)){lines(c(Laxx[j],Lbxx[j]),c(Layy[j],Lbyy[j]),
                                                    col = "blue",lwd = 2.5)})
  dev.off()
}
