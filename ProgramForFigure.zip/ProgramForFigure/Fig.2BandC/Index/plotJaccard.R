rm(list=ls())
require(SuperExactTest)
################################################################################
dir1 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/4 noise/Haar"
dir2 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/4 noise/spectralTAD"
dir3 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/4 noise/HiCDB"
dir4 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/4 noise/IC_Finder"
dir5 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/4 noise/EAST"
dir6 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/4 noise/Topdom"
dir7 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/4 noise/HiCseg"
dir8 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/4 noise/TADs"

datalist <- list()
datalist[[1]] <- sapply(list.files(dir1, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[2]] <- sapply(list.files(dir2, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[3]] <- sapply(list.files(dir3, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[4]] <- sapply(list.files(dir4, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[5]] <- sapply(list.files(dir5, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[6]] <- sapply(list.files(dir6, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[7]] <- sapply(list.files(dir7, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[8]] <- sapply(list.files(dir8, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)

JaccardData <- list()
for(i in 1:7) 
{
  numatrix <-length(datalist[[i]])
  for(j in 1:numatrix)
  {
    datalist[[i]][[j]] <- as.matrix(datalist[[i]][[j]])
  }
  for(k in 1:numatrix)
  {
    datalist[[i]][[numatrix+k]] <- as.matrix(datalist[[8]][[k]])
  }
  
  tmpjimatrix <- jaccard(datalist[[i]])
  tmpjimatrix_use <- tmpjimatrix[1:5,6:10]#change by num of sample
  JaccardData[[i]] <- diag(tmpjimatrix_use)
}

jimatrix <- matrix(NA, length(JaccardData[[1]]), length(JaccardData))
for(i in 1:length(JaccardData))
{
  jimatrix[,i] <- JaccardData[[i]]
}
list4noise <- jimatrix
################################################################################
dir1 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/8 noise/Haar"
dir2 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/8 noise/spectralTAD"
dir3 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/8 noise/HiCDB"
dir4 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/8 noise/IC_Finder"
dir5 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/8 noise/EAST"
dir6 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/8 noise/Topdom"
dir7 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/8 noise/HiCseg"
dir8 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/8 noise/TADs"

datalist <- list()
datalist[[1]] <- sapply(list.files(dir1, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[2]] <- sapply(list.files(dir2, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[3]] <- sapply(list.files(dir3, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[4]] <- sapply(list.files(dir4, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[5]] <- sapply(list.files(dir5, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[6]] <- sapply(list.files(dir6, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[7]] <- sapply(list.files(dir7, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[8]] <- sapply(list.files(dir8, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)

JaccardData <- list()
for(i in 1:7) 
{
  numatrix <-length(datalist[[i]])
  for(j in 1:numatrix)
  {
    datalist[[i]][[j]] <- as.matrix(datalist[[i]][[j]])
  }
  for(k in 1:numatrix)
  {
    datalist[[i]][[numatrix+k]] <- as.matrix(datalist[[8]][[k]])
  }
  
  tmpjimatrix <- jaccard(datalist[[i]])
  tmpjimatrix_use <- tmpjimatrix[1:5,6:10]#change by num of sample
  JaccardData[[i]] <- diag(tmpjimatrix_use)
}

jimatrix <- matrix(NA, length(JaccardData[[1]]), length(JaccardData))
for(i in 1:length(JaccardData))
{
  jimatrix[,i] <- JaccardData[[i]]
}
list8noise <- jimatrix
################################################################################
dir1 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/12 noise/Haar"
dir2 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/12 noise/spectralTAD"
dir3 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/12 noise/HiCDB"
dir4 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/12 noise/IC_Finder"
dir5 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/12 noise/EAST"
dir6 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/12 noise/Topdom"
dir7 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/12 noise/HiCseg"
dir8 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/12 noise/TADs"

datalist <- list()
datalist[[1]] <- sapply(list.files(dir1, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[2]] <- sapply(list.files(dir2, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[3]] <- sapply(list.files(dir3, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[4]] <- sapply(list.files(dir4, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[5]] <- sapply(list.files(dir5, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[6]] <- sapply(list.files(dir6, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[7]] <- sapply(list.files(dir7, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[8]] <- sapply(list.files(dir8, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)

JaccardData <- list()
for(i in 1:7) 
{
  numatrix <-length(datalist[[i]])
  for(j in 1:numatrix)
  {
    datalist[[i]][[j]] <- as.matrix(datalist[[i]][[j]])
  }
  for(k in 1:numatrix)
  {
    datalist[[i]][[numatrix+k]] <- as.matrix(datalist[[8]][[k]])
  }
  
  tmpjimatrix <- jaccard(datalist[[i]])
  tmpjimatrix_use <- tmpjimatrix[1:5,6:10]#change by num of sample
  JaccardData[[i]] <- diag(tmpjimatrix_use)
}

jimatrix <- matrix(NA, length(JaccardData[[1]]), length(JaccardData))
for(i in 1:length(JaccardData))
{
  jimatrix[,i] <- JaccardData[[i]]
}
list12noise <- jimatrix
################################################################################
dir1 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/16 noise/Haar"
dir2 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/16 noise/spectralTAD"
dir3 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/16 noise/HiCDB"
dir4 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/16 noise/IC_Finder"
dir5 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/16 noise/EAST"
dir6 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/16 noise/Topdom"
dir7 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/16 noise/HiCseg"
dir8 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/16 noise/TADs"

datalist <- list()
datalist[[1]] <- sapply(list.files(dir1, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[2]] <- sapply(list.files(dir2, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[3]] <- sapply(list.files(dir3, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[4]] <- sapply(list.files(dir4, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[5]] <- sapply(list.files(dir5, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[6]] <- sapply(list.files(dir6, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[7]] <- sapply(list.files(dir7, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[8]] <- sapply(list.files(dir8, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)

JaccardData <- list()
for(i in 1:7) 
{
  numatrix <-length(datalist[[i]])
  for(j in 1:numatrix)
  {
    datalist[[i]][[j]] <- as.matrix(datalist[[i]][[j]])
  }
  for(k in 1:numatrix)
  {
    datalist[[i]][[numatrix+k]] <- as.matrix(datalist[[8]][[k]])
  }
  
  tmpjimatrix <- jaccard(datalist[[i]])
  tmpjimatrix_use <- tmpjimatrix[1:5,6:10]#change by num of sample
  JaccardData[[i]] <- diag(tmpjimatrix_use)
}

jimatrix <- matrix(NA, length(JaccardData[[1]]), length(JaccardData))
for(i in 1:length(JaccardData))
{
  jimatrix[,i] <- JaccardData[[i]]
}
list16noise <- jimatrix
################################################################################
dir1 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/20 noise/Haar"
dir2 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/20 noise/spectralTAD"
dir3 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/20 noise/HiCDB"
dir4 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/20 noise/IC_Finder"
dir5 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/20 noise/EAST"
dir6 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/20 noise/Topdom"
dir7 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/20 noise/HiCseg"
dir8 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/20 noise/TADs"

datalist <- list()
datalist[[1]] <- sapply(list.files(dir1, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[2]] <- sapply(list.files(dir2, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[3]] <- sapply(list.files(dir3, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[4]] <- sapply(list.files(dir4, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[5]] <- sapply(list.files(dir5, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[6]] <- sapply(list.files(dir6, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[7]] <- sapply(list.files(dir7, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[8]] <- sapply(list.files(dir8, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)

JaccardData <- list()
for(i in 1:7) 
{
  numatrix <-length(datalist[[i]])
  for(j in 1:numatrix)
  {
    datalist[[i]][[j]] <- as.matrix(datalist[[i]][[j]])
  }
  for(k in 1:numatrix)
  {
    datalist[[i]][[numatrix+k]] <- as.matrix(datalist[[8]][[k]])
  }
  
  tmpjimatrix <- jaccard(datalist[[i]])
  tmpjimatrix_use <- tmpjimatrix[1:5,6:10]#change by num of sample
  JaccardData[[i]] <- diag(tmpjimatrix_use)
}

jimatrix <- matrix(NA, length(JaccardData[[1]]), length(JaccardData))
for(i in 1:length(JaccardData))
{
  jimatrix[,i] <- JaccardData[[i]]
}
list20noise <- jimatrix
###########################################################################
final = data.frame(list4noise, list8noise, list12noise, list16noise, list20noise)
level <- 5

col<-c("red","purple","green","blue","magenta","brown","orange")
namefile2 <- "/media/disk1/lilin/1-lilin_xiugai/sim index/JaccardIndex7_seg.TIFF"
tiff(namefile2, width = 4.1, height = 2.75, units = "cm", pointsize=1, res=350)
par(bty = "l", xaxs = "r", yaxs = "r", mar=c(2, 10.3, 0, 0), mgp=c(6,1,0), lwd=0.2, cex.axis=5, cex.lab=5)
boxplot(final, range = 1, outline=FALSE,col=col,ylab="Jaccard index",axes = FALSE, at=which((c(1:((length(col)+1)*level+-1))%%(length(col)+1))!=0))
axis(side = 2, lwd = 0.2)
axis(side = 1, lwd = 0.2, at = which((c(1:((length(col)+1)*level+-1))%%(length(col)+1))!=0), labels=FALSE)
axis.break(1, 7.450, style = "gap",,brw=0.01)
axis.break(1, 15.62, style = "gap",,brw=0.01)
axis.break(1, 23.79, style = "gap",,brw=0.01)
axis.break(1, 31.96, style = "gap",,brw=0.01)
dev.off()


