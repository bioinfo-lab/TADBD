HiCseg_mcc<-function(disdata1,number)
{
  library(HiCseg)
  matrix<-disdata1
  t1<-Sys.time()
  matrix<-as.matrix(matrix)
  dim=dim(matrix)[1]
  result = HiCseg_linkC_R(dim, number, "G", matrix, "D")
  boundary=result$t_hat +1
  return(boundary)
}


