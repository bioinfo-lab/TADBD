rm(list=ls())
setwd("/media/disk1/lilin/1-lilin_xiugai/MCC/MCC")
source("./Topdom/Topdom_mcc.R")
source("./Haar/Haar_mcc.old.R")
source("./HiCDB/HiCDB_mcc.R")
source("./HiCseg/HiCseg_mcc.R")
source("./spectralTAD/spectralTAD_mcc.R")

getmccscore<-function(score_simulated,score_method)
{
  TP <- 0
  TN <- 0
  FP <- 0
  FN <- 0
  score_X <- score_method
  for(i in 1:length(score_simulated)){
    if(score_simulated[i]==0 & score_X[i]==0)
    {
      TN <- TN + 1
    }
    if(score_simulated[i]==1 & score_X[i]==0)
    {
      FN <- FN + 1
    }
    if(score_simulated[i]==0 & score_X[i]==1)
    {
      FP <- FP + 1
    }
    if(score_simulated[i]==1 & score_X[i]==1)
    {
      TP <- TP + 1
    }
  }
  MCC_score <- (TP*TN-FN*FP)/sqrt((TP+FN)*(TP+FP)*(TN+FN)*(TN+FP))
  return(MCC_score)
}

dir <- "/media/disk1/lilin/1-lilin_xiugai/MCC/simu"
dirlist <- list.files(dir, full.names=TRUE)
datalist4 <- list.files(dirlist[4], full.names=TRUE)
datalist4n <- list.files(datalist4[1], full.names=TRUE)
datalist4TADs <- list.files(datalist4[2], full.names=TRUE)
datalist8 <- list.files(dirlist[5], full.names=TRUE)
datalist8n <- list.files(datalist8[1], full.names=TRUE)
datalist8TADs <- list.files(datalist8[2], full.names=TRUE)
datalist12 <- list.files(dirlist[1], full.names=TRUE)
datalist12n <- list.files(datalist12[1], full.names=TRUE)
datalist12TADs <- list.files(datalist12[2], full.names=TRUE)
datalist16 <- list.files(dirlist[2], full.names=TRUE)
datalist16n <- list.files(datalist16[1], full.names=TRUE)
datalist16TADs <- list.files(datalist16[2], full.names=TRUE)
datalist20 <- list.files(dirlist[3], full.names=TRUE)
datalist20n <- list.files(datalist20[1], full.names=TRUE)
datalist20TADs <- list.files(datalist20[2], full.names=TRUE)
############### 4 noise #################################
for (i_sample in 1:5) {
    sim_point<- read.table(datalist4TADs[i_sample],head=FALSE)
    sim_point<-sim_point$V1
    sim_point<-sim_point[3:length(sim_point)]
    sim_point<-as.matrix(sim_point)
    sim_point<-as.numeric(sim_point)/40000
    c1 <- sim_point[1:length(sim_point)]+1
    disdata1<- read.table(datalist4n[i_sample])
    disdata1<-as.matrix(disdata1)
    score_simulated <- matrix(0, nrow = 1, ncol = ncol(disdata1))
    for (i in 1:length(c1)) {
      score_simulated[c1[i]] <- 1
    }
    score_simulated <- c(score_simulated)
    # score_EAST ###################################################
    path0 <- "/media/disk1/lilin/1-lilin_xiugai/NewMethod/EAST/Result/RawSimu/4 noise/data"
    path1 <- ".txt_res.txt"
    path <- paste(path0,i_sample,path1)
    c6 <- read.table(path,head=FALSE)
    c6 <- as.matrix(c6)+1
    c6<-c6[,1]
    # c6<-c6[2:length(c6)]
    score_EAST <- matrix(0, nrow = 1, ncol = nrow(disdata1))
    for (i in 1:length(c6)) {
      score_EAST[c6[i]] <- 1
    }
    score_EAST <- c(score_EAST)
    Mcc_EAST<-getmccscore(score_simulated,score_EAST)
    print("Mcc_EAST:")
    print(Mcc_EAST)
    write.table(Mcc_EAST, file = "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/EAST/MCC_EAST.txt", append = T, sep = "  ", row.names = FALSE, col.names = FALSE)
    Wpath0 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/4 noise/EAST/EAST_"
    Wpath1 <- ".dom"
    Wpath <- paste(Wpath0,i_sample,Wpath1,sep = "")
    write.table(c6, file = Wpath, append = FALSE, sep = "  ", row.names = FALSE, col.names = TRUE)
    
}
############### 8 noise #################################
for (i_sample in 1:5) {
  sim_point<- read.table(datalist8TADs[i_sample],head=FALSE)
  sim_point<-sim_point$V1
  sim_point<-sim_point[3:length(sim_point)]
  sim_point<-as.matrix(sim_point)
  sim_point<-as.numeric(sim_point)/40000
  c1 <- sim_point[1:length(sim_point)]+1
  disdata1<- read.table(datalist8n[i_sample])
  disdata1<-as.matrix(disdata1)
  score_simulated <- matrix(0, nrow = 1, ncol = ncol(disdata1))
  for (i in 1:length(c1)) {
    score_simulated[c1[i]] <- 1
  }
  score_simulated <- c(score_simulated)
  # score_EAST ###################################################
  path0 <- "/media/disk1/lilin/1-lilin_xiugai/NewMethod/EAST/Result/RawSimu/8 noise/data"
  path1 <- ".txt_res.txt"
  path <- paste(path0,i_sample,path1)
  c6 <- read.table(path,head=FALSE)
  c6 <- as.matrix(c6)+1
  c6<-c6[,1]
  # c6<-c6[2:length(c6)]
  score_EAST <- matrix(0, nrow = 1, ncol = nrow(disdata1))
  for (i in 1:length(c6)) {
    score_EAST[c6[i]] <- 1
  }
  score_EAST <- c(score_EAST)
  Mcc_EAST<-getmccscore(score_simulated,score_EAST)
  print("Mcc_EAST:")
  print(Mcc_EAST)
  write.table(Mcc_EAST, file = "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/EAST/MCC_EAST.txt", append = T, sep = "  ", row.names = FALSE, col.names = FALSE)
  Wpath0 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/8 noise/EAST/EAST_"
  Wpath1 <- ".dom"
  Wpath <- paste(Wpath0,i_sample,Wpath1,sep = "")
  write.table(c6, file = Wpath, append = FALSE, sep = "  ", row.names = FALSE, col.names = TRUE)
  
}
############### 12 noise #################################
for (i_sample in 1:5) {
  sim_point<- read.table(datalist12TADs[i_sample],head=FALSE)
  sim_point<-sim_point$V1
  sim_point<-sim_point[3:length(sim_point)]
  sim_point<-as.matrix(sim_point)
  sim_point<-as.numeric(sim_point)/40000
  c1 <- sim_point[1:length(sim_point)]+1
  disdata1<- read.table(datalist12n[i_sample])
  disdata1<-as.matrix(disdata1)
  score_simulated <- matrix(0, nrow = 1, ncol = ncol(disdata1))
  for (i in 1:length(c1)) {
    score_simulated[c1[i]] <- 1
  }
  score_simulated <- c(score_simulated)
  # score_EAST ###################################################
  path0 <- "/media/disk1/lilin/1-lilin_xiugai/NewMethod/EAST/Result/RawSimu/12 noise/data"
  path1 <- ".txt_res.txt"
  path <- paste(path0,i_sample,path1)
  c6 <- read.table(path,head=FALSE)
  c6 <- as.matrix(c6)+1
  c6<-c6[,1]
  # c6<-c6[2:length(c6)]
  score_EAST <- matrix(0, nrow = 1, ncol = nrow(disdata1))
  for (i in 1:length(c6)) {
    score_EAST[c6[i]] <- 1
  }
  score_EAST <- c(score_EAST)
  Mcc_EAST<-getmccscore(score_simulated,score_EAST)
  print("Mcc_EAST:")
  print(Mcc_EAST)
  write.table(Mcc_EAST, file = "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/EAST/MCC_EAST.txt", append = T, sep = "  ", row.names = FALSE, col.names = FALSE)
  Wpath0 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/12 noise/EAST/EAST_"
  Wpath1 <- ".dom"
  Wpath <- paste(Wpath0,i_sample,Wpath1,sep = "")
  write.table(c6, file = Wpath, append = FALSE, sep = "  ", row.names = FALSE, col.names = TRUE)
  
}
############### 16 noise #################################
for (i_sample in 1:5) {
  sim_point<- read.table(datalist16TADs[i_sample],head=FALSE)
  sim_point<-sim_point$V1
  sim_point<-sim_point[3:length(sim_point)]
  sim_point<-as.matrix(sim_point)
  sim_point<-as.numeric(sim_point)/40000
  c1 <- sim_point[1:length(sim_point)]+1
  disdata1<- read.table(datalist16n[i_sample])
  disdata1<-as.matrix(disdata1)
  score_simulated <- matrix(0, nrow = 1, ncol = ncol(disdata1))
  for (i in 1:length(c1)) {
    score_simulated[c1[i]] <- 1
  }
  score_simulated <- c(score_simulated)
  # score_EAST ###################################################
  path0 <- "/media/disk1/lilin/1-lilin_xiugai/NewMethod/EAST/Result/RawSimu/16 noise/data"
  path1 <- ".txt_res.txt"
  path <- paste(path0,i_sample,path1)
  c6 <- read.table(path,head=FALSE)
  c6 <- as.matrix(c6)+1
  c6<-c6[,1]
  # c6<-c6[2:length(c6)]
  score_EAST <- matrix(0, nrow = 1, ncol = nrow(disdata1))
  for (i in 1:length(c6)) {
    score_EAST[c6[i]] <- 1
  }
  score_EAST <- c(score_EAST)
  Mcc_EAST<-getmccscore(score_simulated,score_EAST)
  print("Mcc_EAST:")
  print(Mcc_EAST)
  write.table(Mcc_EAST, file = "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/EAST/MCC_EAST.txt", append = T, sep = "  ", row.names = FALSE, col.names = FALSE)
  Wpath0 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/16 noise/EAST/EAST_"
  Wpath1 <- ".dom"
  Wpath <- paste(Wpath0,i_sample,Wpath1,sep = "")
  write.table(c6, file = Wpath, append = FALSE, sep = "  ", row.names = FALSE, col.names = TRUE)
  
}
############### 20 noise #################################
for (i_sample in 1:5) {
  sim_point<- read.table(datalist20TADs[i_sample],head=FALSE)
  sim_point<-sim_point$V1
  sim_point<-sim_point[3:length(sim_point)]
  sim_point<-as.matrix(sim_point)
  sim_point<-as.numeric(sim_point)/40000
  c1 <- sim_point[1:length(sim_point)]+1
  disdata1<- read.table(datalist20n[i_sample])
  disdata1<-as.matrix(disdata1)
  score_simulated <- matrix(0, nrow = 1, ncol = ncol(disdata1))
  for (i in 1:length(c1)) {
    score_simulated[c1[i]] <- 1
  }
  score_simulated <- c(score_simulated)
  # score_EAST ###################################################
  path0 <- "/media/disk1/lilin/1-lilin_xiugai/NewMethod/EAST/Result/RawSimu/20 noise/data"
  path1 <- ".txt_res.txt"
  path <- paste(path0,i_sample,path1)
  c6 <- read.table(path,head=FALSE)
  c6 <- as.matrix(c6)+1
  c6<-c6[,1]
  # c6<-c6[2:length(c6)]
  score_EAST <- matrix(0, nrow = 1, ncol = nrow(disdata1))
  for (i in 1:length(c6)) {
    score_EAST[c6[i]] <- 1
  }
  score_EAST <- c(score_EAST)
  Mcc_EAST<-getmccscore(score_simulated,score_EAST)
  print("Mcc_EAST:")
  print(Mcc_EAST)
  write.table(Mcc_EAST, file = "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/EAST/MCC_EAST.txt", append = T, sep = "  ", row.names = FALSE, col.names = FALSE)
  Wpath0 <- "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/20 noise/EAST/EAST_"
  Wpath1 <- ".dom"
  Wpath <- paste(Wpath0,i_sample,Wpath1,sep = "")
  write.table(c6, file = Wpath, append = FALSE, sep = "  ", row.names = FALSE, col.names = TRUE)
  
}