HiCDB_mcc<-function(disdata1)
{
  source("/media/disk1/lilin/simulated heatmap/MCC/HiCDB/RHiCDB.r")
  source("/media/disk1/lilin/simulated heatmap/MCC/HiCDB/sub_func.r")
  # require(gplots)
  # require(ggplot2)
  # require(pheatmap)
  # require(quantmod)
  #disdata1<- read.table("D:/gra project/input/simulated_data/1/50K_1/chr14_simdata_25K_part_ 1 .txt",head=FALSE)
  disdata1<-as.matrix(disdata1)
  allpeaks=as.data.frame(matrix(numeric(0),ncol=4))
  allLRI=as.data.frame(matrix(numeric(0),ncol=4))
  allaRI=as.data.frame(matrix(numeric(0),ncol=4))
  
  wd=25
  wdsize=30
  N=ncol(disdata1)
  im=disdata1
  
  
  
  out=KRnorm(im)
  imnew=out$imKR
  gapidx=out$gapidx
  
  
  
  tmpx = log(1+imnew)
  tmpn = nrow(tmpx)
  tads = zeros(wdsize,tmpn)
  
  for (w in( wd:(wd+wdsize-1) )){
    xx = (w+1):(tmpn-w-1)
    sumup = 0
    for (i in (-w:-1))
      for (j in ((i+1):0))
        sumup = sumup+tmpx[xx+i+ tmpn*( xx+j-1)]
    
    sumdown = 0
    for (i in 1:w)
      for (j in (i+1):(w+1))
        sumdown = sumdown+tmpx[xx+i+ tmpn*( xx+j-1)]
    
    sumrect = 0
    for (i in (-w+1):0)
      for (j in (1:(w+i)))
        sumrect = sumrect+tmpx[xx+i+ tmpn*( xx+j-1)]
    
    tadscores = (sumup+sumdown-sumrect)/(sumup+sumdown+sumrect)
    tadscores = cbind (t(rep(tadscores[1],w)), t(tadscores) ,t(rep(tadscores[length(tadscores)],w+1)))
    tads[w-wd+1,] = tadscores
  }
  tadscores = colMeans(tads)
  
  
  temp = envelope(tadscores)
  ylower = as.matrix(temp[4])
  
  temp = envelope(ylower)
  ylower2 = as.matrix(temp[4])
  
  peakscore=tadscores-ylower2
  LRI=peakscore
  LRI=as.matrix(LRI)
  
  temp = findpeaks(tadscores)
  TAD_boundaries = temp[,2]+1
  return(TAD_boundaries)
}

