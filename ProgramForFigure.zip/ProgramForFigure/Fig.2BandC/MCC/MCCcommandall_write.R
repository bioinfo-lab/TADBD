rm(list=ls())
setwd("/media/disk1/lilin/1-lilin_xiugai/MCC/MCC")
source("./Topdom/Topdom_mcc.R")
source("./Haar/Haar_mcc.old.R")
source("./HiCDB/HiCDB_mcc.R")
source("./HiCseg/HiCseg_mcc.R")
source("./spectralTAD/spectralTAD_mcc.R")
getmccscore<-function(score_simulated,score_method)
{
  TP <- 0
  TN <- 0
  FP <- 0
  FN <- 0
  score_X <- score_method
  for(i in 1:length(score_simulated)){
    if(score_simulated[i]==0 & score_X[i]==0)
    {
      TN <- TN + 1
    }
    if(score_simulated[i]==1 & score_X[i]==0)
    {
      FN <- FN + 1
    }
    if(score_simulated[i]==0 & score_X[i]==1)
    {
      FP <- FP + 1
    }
    if(score_simulated[i]==1 & score_X[i]==1)
    {
      TP <- TP + 1
    }
  }
  MCC_score <- (TP*TN-FN*FP)/sqrt((TP+FN)*(TP+FP)*(TN+FN)*(TN+FP))
  return(MCC_score)
}

disdata1<- read.table("./results/20 noise/data/data5.txt",head=FALSE)
sim_point<- read.table("./results/20 noise/tads/tads5.txt",head=FALSE)
disdata1<-as.matrix(disdata1)
sim_point<-sim_point$V1
sim_point<-sim_point[3:length(sim_point)]
sim_point<-as.matrix(sim_point)
sim_point<-as.numeric(sim_point)/40000
c1 <- sim_point[1:length(sim_point)]+1
score_simulated <- matrix(0, nrow = 1, ncol = ncol(disdata1))
for (i in 1:length(c1)) {
  score_simulated[c1[i]] <- 1
}
score_simulated <- c(score_simulated)
write.table(c1, file = "./results/20 noise/TADs/TADs5.dom", append = FALSE,
            sep = "  ", row.names = FALSE, col.names = TRUE)

############ score_haar #####################
haar_domain <- Haar_mcc(disdata1)
c2 <- as.matrix(haar_domain)
c2 <- sort(c2)
score_haar <- matrix(0, nrow = 1, ncol = nrow(disdata1) )
for (i in 1:length(c2)) {
  score_haar[c2[i]] <- 1
}
score_haar <- c(score_haar)
Mcc_haar<-getmccscore(score_simulated,score_haar)
print("Mcc_haar:")
print(Mcc_haar)
write.table(c2, file = "./results/20 noise/Haar/TADBD5.dom", append = FALSE,
            sep = "  ", row.names = FALSE, col.names = TRUE)
############### score_topdom ###############
c3 <- Topdom_mcc(disdata1)
c3 <- as.matrix(c3)
score_topdom <- matrix(0, nrow = 1, ncol = nrow(disdata1) )
for (i in 1:length(c3)) {
  score_topdom[c3[i]] <- 1
}
score_topdom <- c(score_topdom)
Mcc_topdom<-getmccscore(score_simulated,score_topdom)
print("Mcc_topdom:")
print(Mcc_topdom)
write.table(c3, file = "./results/20 noise/Topdom/TopDom5.dom", append = FALSE,
            sep = "  ", row.names = FALSE, col.names = TRUE)
############### score_HiCDB ##############
c4 <- HiCDB_mcc(disdata1)
c4 <- as.matrix(c4)
score_HiCDB <- matrix(0, nrow = 1, ncol = nrow(disdata1) )
for (i in 1:length(c4)) {
  score_HiCDB[c4[i]] <- 1
}
score_HiCDB <- c(score_HiCDB)
Mcc_HiCDB<-getmccscore(score_simulated,score_HiCDB)
print("Mcc_HiCDB:")
print(Mcc_HiCDB)
write.table(c4, file = "./results/20 noise/HiCDB/HiCDB5.dom", append = FALSE,
            sep = "  ", row.names = FALSE, col.names = TRUE)
################ score_HiCseg ###############
c5 <- HiCseg_mcc(disdata1,100)
c5 <- as.matrix(c5)
score_HiCseg <- matrix(0, nrow = 1, ncol = nrow(disdata1) )
for (i in 1:length(c5)) {
  score_HiCseg[c5[i]] <- 1
}
score_HiCseg <- c(score_HiCseg)
Mcc_HiCseg<-getmccscore(score_simulated,score_HiCseg)
print("Mcc_HiCseg:")
print(Mcc_HiCseg)
write.table(c5, file = "./results/20 noise/HiCseg/HiCseg5.dom", append = FALSE,
            sep = "  ", row.names = FALSE, col.names = TRUE)
################## SpectalTAD ###########################
spectral_domain <- spectralTAD_mcc(disdata1)+1
c6 <- as.matrix(spectral_domain)
score_specral <- matrix(0, nrow = 1, ncol = nrow(disdata1) )
for (i in 1:length(c6)) {
  score_specral[c6[i]] <- 1
}
score_specral <- c(score_specral)
Mcc_spectral <- getmccscore(score_simulated,score_specral)
print("Mcc_SpectralTAD:")
print(Mcc_spectral)
write.table(c6, file = "/media/disk1/lilin/1-lilin_xiugai/MCC/MCC/results/20 noise/spectralTAD/spectralTAD5.dom", append = FALSE, sep = "  ", row.names = FALSE, col.names = TRUE)

# score_IC_Finder
c7 <- read.table("/media/disk1/lilin/simulated heatmap/MCC/simu/20 noise/data/data1_domains.txt",head=FALSE)
c7 <- as.matrix(c7)
c7<-c7[,1]
c7<-c7[2:length(c7)]
score_IC_Finder <- matrix(0, nrow = 1, ncol = nrow(disdata1))
for (i in 1:length(c7)) {
 score_IC_Finder[c7[i]] <- 1
}
score_IC_Finder <- c(score_IC_Finder)
Mcc_IC_Finder<-getmccscore(score_simulated,score_IC_Finder)
print("Mcc_IC_Finder:")
print(Mcc_IC_Finder)
write.table(c7, file = "/media/disk1/lilin/simulated heatmap/boundry/IC_Finder/IC_Finder20.dom", append = FALSE,
            sep = "  ", row.names = FALSE, col.names = TRUE)