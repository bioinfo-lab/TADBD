spectralTAD_mcc <- function(disdata1){
  library("SpectralTAD", lib.loc="~/R/x86_64-pc-linux-gnu-library/3.6")
  setwd("/media/disk1/lilin/1-lilin_xiugai/MCC")
  source("./spectralTAD/matrix2sparse.R")
  disdata1<-as.matrix(disdata1)
  spar <- matrix2sparse(disdata1, resolution = 40000)
  # spec_table <- SpectralTAD(spar, qual_filter = TRUE, eigenvalues = 2, min_size = 5, resolution = 100000, gap_threshold = .5, chr= 'chr1')
  spec_table <- SpectralTAD(spar, chr= 'chr18',resolution = 40000, min_size = 10, qual_filter = TRUE)
  boundry <- c(spec_table[["Level_1"]][["end"]])/40000
  return(boundry)
}
