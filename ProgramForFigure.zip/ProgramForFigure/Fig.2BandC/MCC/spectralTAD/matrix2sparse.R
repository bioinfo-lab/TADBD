matrix2sparse <- function(hicmat, resolution) 
{
  library(Matrix)
  if (nrow(hicmat) == ncol(hicmat))
  {
    hicmat[lower.tri(hicmat)] = 0
    sparsedf <- summary(Matrix(hicmat, sparse = TRUE))
    sparsedf <- as.data.frame(sparsedf)
    names(sparsedf)=c("start","end","IF")
    sparsedf[,1:2]=(sparsedf[,1:2]-1)*resolution
    return(sparsedf)
  }
  else
  {
    stop("The number of columns does not equal to the number of rows")       
  }
}
