Topdom_mcc<-function(disdata1)
{
  source("/media/disk1/lilin/simulated heatmap/MCC/Topdom/TopDom.R")
  # source("D:/gra project/spare2martix/sparse2matrix.R")
  # require(gplots)
  # require(ggplot2)
  # require(pheatmap)
  matdf<- disdata1
  window.size=5
  n_bins = nrow(matdf)
  mean.cf <- rep(0, n_bins)
  pvalue <- rep(1, n_bins)
  local.ext = rep(-0.5, n_bins)
  matrix.data <- as.matrix( matdf[, (ncol(matdf) - nrow(matdf)+1 ):ncol(matdf)] )
  for(i in 1:n_bins)
  {
    diamond = Get.Diamond.Matrix(mat.data=matrix.data, i=i, size=window.size)
    mean.cf[i] = mean(diamond)
  }
  gap.idx = Which.Gap.Region2(matrix.data=matrix.data, window.size)
  proc.regions = Which.process.region(rmv.idx=gap.idx, n_bins=n_bins, min.size=3)
  
  for( i in 1:nrow(proc.regions))
  {
    start = proc.regions[i, "start"]
    end = proc.regions[i, "end"]
    
    local.ext[start:end] = Detect.Local.Extreme(x=mean.cf[start:end])
  }
  
  scale.matrix.data = matrix.data
  for( i in 1:(2*window.size) )
  {
    #diag(scale.matrix.data[, i:n_bins] ) = scale( diag( matrix.data[, i:n_bins] ) )
    scale.matrix.data[ seq(1+(n_bins*i), n_bins*n_bins, 1+n_bins) ] = scale( matrix.data[ seq(1+(n_bins*i), n_bins*n_bins, 1+n_bins) ] )
  }
  for( i in 1:nrow(proc.regions))
  {
    start = proc.regions[i, "start"]
    end = proc.regions[i, "end"]
    pvalue[start:end] <- Get.Pvalue(matrix.data=scale.matrix.data[start:end, start:end], size=window.size, scale=1)
  }
  local.ext[intersect( union(which( local.ext==-1), which(local.ext==-1)), which(pvalue<0.05))] = -2
  local.ext[which(local.ext==-1)] = 0
  local.ext[which(local.ext==-2)] = -1
  signal.idx=which(local.ext==-1) +1
  return(signal.idx)
}

