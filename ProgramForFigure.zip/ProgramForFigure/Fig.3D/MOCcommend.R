rm(list=ls())
setwd("/media/disk1/lilin/1-lilin_xiugai/def parameters/real")
source("./MoC.R")

MOCvalue <- function(dir1path, dir2path){
  dir1 <- list.files(dir1path, full.names=TRUE)
  dir2 <- list.files(dir2path, full.names=TRUE)
  mocalue <- c()
  for (i in 1:6) {
    list1 <- read.table(dir1[i],header = T)
    list2 <- read.table(dir2[1],header = T)
    moc <- MoC(list1, list2)
    mocalue <- c(mocalue,moc)
    list1 <- read.table(dir1[i],header = T)
    list2 <- read.table(dir2[2],header = T)
    moc <- MoC(list1, list2)
    mocalue <- c(mocalue,moc)
    list1 <- read.table(dir1[i],header = T)
    list2 <- read.table(dir2[3],header = T)
    moc <- MoC(list1, list2)
    mocalue <- c(mocalue,moc)
    list1 <- read.table(dir1[i],header = T)
    list2 <- read.table(dir2[4],header = T)
    moc <- MoC(list1, list2)
    mocalue <- c(mocalue,moc)
    list1 <- read.table(dir1[i],header = T)
    list2 <- read.table(dir2[5],header = T)
    moc <- MoC(list1, list2)
    mocalue <- c(mocalue,moc)
    list1 <- read.table(dir1[i],header = T)
    list2 <- read.table(dir2[6],header = T)
    moc <- MoC(list1, list2)
    mocalue <- c(mocalue,moc)
  }
  return(mocalue)
}

dir1path <- "./result-K562-chr1-50k/size234"
dir2path <- "./result-K562-chr1-50k/size345"
MOC234_345 <- MOCvalue(dir1path,dir2path)
dir1path <- "./result-K562-chr1-50k/size234"
dir2path <- "./result-K562-chr1-50k/size456"
MOC234_456 <- MOCvalue(dir1path,dir2path)
dir1path <- "./result-K562-chr1-50k/size234"
dir2path <- "./result-K562-chr1-50k/size567"
MOC234_567 <- MOCvalue(dir1path,dir2path)
dir1path <- "./result-K562-chr1-50k/size234"
dir2path <- "./result-K562-chr1-50k/size678"
MOC234_678 <- MOCvalue(dir1path,dir2path)
dir1path <- "./result-K562-chr1-50k/size345"
dir2path <- "./result-K562-chr1-50k/size456"
MOC345_456 <- MOCvalue(dir1path,dir2path)
dir1path <- "./result-K562-chr1-50k/size345"
dir2path <- "./result-K562-chr1-50k/size567"
MOC345_567 <- MOCvalue(dir1path,dir2path)
dir1path <- "./result-K562-chr1-50k/size345"
dir2path <- "./result-K562-chr1-50k/size678"
MOC345_678 <- MOCvalue(dir1path,dir2path)
dir1path <- "./result-K562-chr1-50k/size456"
dir2path <- "./result-K562-chr1-50k/size567"
MOC456_567 <- MOCvalue(dir1path,dir2path)
dir1path <- "./result-K562-chr1-50k/size456"
dir2path <- "./result-K562-chr1-50k/size678"
MOC456_678 <- MOCvalue(dir1path,dir2path)
dir1path <- "./result-K562-chr1-50k/size567"
dir2path <- "./result-K562-chr1-50k/size678"
MOC567_678 <- MOCvalue(dir1path,dir2path)
listall <- list(MOC234_345,MOC234_456,MOC234_567,MOC234_678,MOC345_456,MOC345_567,MOC345_678,MOC456_567,MOC456_678,MOC567_678)

names<-c("2,3,4-3,4,5","2,3,4-4,5,6","2,3,4-5,6,7","2,3,4-6,7,8","3,4,5-4,5,6","3,4,5-5,6,7","3,4,5-6,7,8","4,5,6-5,6,7","4,5,6-6,7,8","5,6,7-6,7,8")
tiff("/media/disk1/lilin/1-lilin_xiugai/def parameters/real/MoCboxK562.TIFF", width = 4.1, height = 4.1, units = "cm", pointsize=1, res=350)
par(bty = "l", xaxs = "r", yaxs = "r", mar=c(25, 10.3, 0, 0), mgp=c(6,1,0), lwd=0.2, cex.axis=5, cex.lab=5)
boxplot(listall, range = 1, outline=FALSE,col=col,ylab="MoC",axes = FALSE)
axis(side = 1, lwd = 0.2, las = 2, at = 1:length(names), labels = names)
axis(side = 2, lwd = 0.2)
dev.off()


