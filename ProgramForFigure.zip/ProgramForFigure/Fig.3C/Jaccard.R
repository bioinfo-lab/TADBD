rm(list=ls())
require(SuperExactTest)
################################################################################
dir1 <- "/media/disk1/lilin/1-lilin_xiugai/def parameters/simu/Result/4 noise/size234"
dir2 <- "/media/disk1/lilin/1-lilin_xiugai/def parameters/simu/Result/4 noise/size345"
dir3 <- "/media/disk1/lilin/1-lilin_xiugai/def parameters/simu/Result/4 noise/size456"
dir4 <- "/media/disk1/lilin/1-lilin_xiugai/def parameters/simu/Result/4 noise/size567"
dir5 <- "/media/disk1/lilin/1-lilin_xiugai/def parameters/simu/Result/4 noise/size678"
dir6 <- "/media/disk1/lilin/1-lilin_xiugai/def parameters/simu/Result/4 noise/TADs"

datalist <- list()
datalist[[1]] <- sapply(list.files(dir1, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[2]] <- sapply(list.files(dir2, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[3]] <- sapply(list.files(dir3, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[4]] <- sapply(list.files(dir4, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[5]] <- sapply(list.files(dir5, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)
datalist[[6]] <- sapply(list.files(dir6, pattern=".dom", full.names=TRUE), read.table, simplify = FALSE, USE.NAMES = TRUE)


JaccardData <- list()
for(i in 1:5)
{
  numatrix <-length(datalist[[i]])
  for(j in 1:numatrix)
  {
    datalist[[i]][[j]] <- as.matrix(datalist[[i]][[j]])
  }
  for(k in 1:numatrix)
  {
    datalist[[i]][[numatrix+k]] <- as.matrix(datalist[[6]][[k]])
  }

  tmpjimatrix <- jaccard(datalist[[i]])
  tmpjimatrix_use <- tmpjimatrix[1:5,6:10]#change by num of sample
  JaccardData[[i]] <- diag(tmpjimatrix_use)
}

jimatrix <- matrix(NA, length(JaccardData[[1]]), length(JaccardData))
for(i in 1:length(JaccardData))
{
  jimatrix[,i] <- JaccardData[[i]]
}
list4noise <- jimatrix
###########################################################################
names<-c("2,3,4","3,4,5","4,5,6","5,6,7","6,7,8")
col<-c("red","green","blue","brown","orange") 
tiff("/media/disk1/lilin/1-lilin_xiugai/def parameters/simu/Result/JaccardIndex.TIFF", width = 4.1, height = 4.1, units = "cm", pointsize=1, res=350)
par(bty = "l", xaxs = "r", yaxs = "r", mar=c(12, 10.3, 0, 0), mgp=c(6,1,0), lwd=0.2, cex.axis=5, cex.lab=5)
boxplot(jimatrix, range = 1, outline=FALSE,col=col,ylab="Jaccard index",axes = FALSE)
axis(side = 1, lwd = 0.2, las = 2, at = 1:length(names), labels = names)
axis(side = 2, lwd = 0.2)
dev.off()
