MoC <- function(list1, list2)
{
  data1 <- list1$x
  data2 <- list2$x
  
  # NP: number of TADs in set P; NQ: number of TADs in set Q
  NP <- length(data1)-1
  NQ <- length(data2)-1
  
  #P/Q is the vector of number of base pairs of ith/jth TAD in set P/Q
  P <- c()
  Q <- c()
  F_lap <- matrix(NA,NP,NQ)
  MoC_F <- matrix(NA,NP,NQ)
  
  for (i in 1:NP) 
  {
    #number of base pairs of ith TAD in P
    P[i] <- data1[i+1]-data1[i]
    for (j in 1:NQ) 
    {
      #number of base pairs of ith TAD in Q
      Q[j] <- data2[j+1]-data2[j]
      imax <- max(data1[i],data2[j])
      jmin <- min(data1[i+1],data2[j+1])
      if(imax>jmin)
      {
        F_lap[i,j] <- 0
      }
      else
      {
        F_lap[i,j] <- jmin-imax
      }
      MoC_F[i,j] <- F_lap[i,j]^2/P[i]/Q[j]
    }
  }
  
  MoC <- ifelse(NP==1&&NQ==1, 1, (sum(MoC_F)-1)/(sqrt(NP*NQ)-1))
  
  return(MoC)
  
}