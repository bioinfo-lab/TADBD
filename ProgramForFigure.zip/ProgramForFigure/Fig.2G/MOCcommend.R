rm(list=ls())
setwd("/media/disk1/lilin/1-lilin_xiugai/real result/pic code/MoC")
source("./MoC.R")

MOC <- function(path){
  dir <- list.files(path,full.names = T)
  mocvalue <- c()
  for (i in 1:5) {
    for (j in (i+1):6) {
      list1 <- (read.table(dir[i],header = T))
      list2 <- (read.table(dir[j],header = T))
      moc <- MoC(list1, list2)
      mocvalue <- c(mocvalue,moc)
    }
  }
  return(mocvalue)
}

dirpath <- "/media/disk1/lilin/1-lilin_xiugai/real result/all results/IMR90-chr18-100k"
dirall <- list.files(dirpath,full.names = T)

TADBDmoc <- MOC(dirall[3])
Spectralmoc <- MOC(dirall[6])
HiCDBmoc <- MOC(dirall[5])
ICFindermoc <- MOC(dirall[4])
EASTmoc <- MOC(dirall[1])
Topdommoc <- MOC(dirall[7])
HiCsegmoc <- MOC(dirall[2])

final=list(TADBDmoc,Spectralmoc,HiCDBmoc,ICFindermoc,EASTmoc,Topdommoc,HiCsegmoc)
col<-c("red","purple","green","blue","magenta","brown","orange")
names<-c("TADBD","SpectralTAD","HiCDB","IC-Finder","EAST","TopDom","HiCseg")
tiff("/media/disk1/lilin/1-lilin_xiugai/real result/pic results_50000/IMR90-chr18-100k/MoC.TIFF", width = 2.73, height = 2.75, units = "cm", pointsize=1, res=350)
par(bty = "l", xaxs = "r", yaxs = "r", mar=c(27, 10.3, 3, 0), mgp=c(6,1,0), lwd=0.2, cex.axis=5, cex.lab=5)
boxplot(final, range = 1, outline=FALSE,col=col,ylab="MoC",axes = FALSE)#pars = list(boxwex = 0.5, staplewex = 0.5, outwex = 0.5)
axis(side = 1, lwd = 0.2, las = 2, at = 1:length(names), labels = names)
axis(side = 2, lwd = 0.2)
dev.off()
