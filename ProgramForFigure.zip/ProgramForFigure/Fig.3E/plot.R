rm(list=ls())
library("gplots", lib.loc="~/R/x86_64-pc-linux-gnu-library/3.6")
setwd("/media/disk1/lilin/1-lilin_xiugai/def resolution/Caculation1")

list1 <- read.table("/media/disk1/lilin/1-lilin_xiugai/def resolution/Caculation1/IMR90-chr18-25k.txt")
list1 <- as.matrix(list1)
list2 <- read.table("/media/disk1/lilin/1-lilin_xiugai/def resolution/Caculation1/IMR90-chr18-50k.txt")
list2 <- as.matrix(list2)
list3 <- read.table("/media/disk1/lilin/1-lilin_xiugai/def resolution/Caculation1/IMR90-chr18-100k.txt")
list3 <- as.matrix(list3)
list4 <- read.table("/media/disk1/lilin/1-lilin_xiugai/def resolution/Caculation1/IMR90-chr18-250k.txt")
list4 <- as.matrix(list4)
listall <-c(list1,list2,list3,list4)
m1 <- matrix(listall,nrow=7,ncol=4,dimnames=list(c("TADBD","SpectralTAD","HiCDB","IC-Finder","EAST","TopDom","HiCseg"),c("25","50","100","250")))

hM <- format(round(m1, 2))
tiff("./IMR90-chr18-new.TIFF", width = 8.2, height = 8.4, units = "cm", pointsize=1, res=350)
par(bty = "l", xaxs = "r", yaxs = "r", mar=c(0, 10.3, 4, 6), mgp=c(6,1,0), lwd=0.2, cex.axis=5, cex.lab=5)

heatmap.2(m1, Rowv=FALSE,col=colorpanel(128,"lightyellow","red"),symm=TRUE,dendrogram="none",
          trace = "none",density.info="none",key=FALSE, cexRow=10, cexCol = 10,notecex = 8.5,
          lmat=rbind(c(1,4),c(3,2)),lhei=c(4,1),lwid=c(4,1),cellnote=hM,notecol="greenyellow")
dev.off()
